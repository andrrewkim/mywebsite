_____  Andrew Kim (20935314) Assignment 3 Final Website _______

Hello! I have put screengrabs in the screengrabs folder for the proper viewing of my website.
I reccomend using Google Chrome, I'm not sure for other browsers as I have only viewed it in Google Chrome.
As for the viewing screen size, I'm not sure what it looks like on other screens as it was very difficult to make my webpage responsive. 
However for my screen, I feel the optimal viewing (or what I designed on) was 125% on WINDOWS NOT google chrome, with a resolution
of 1920 x 1080